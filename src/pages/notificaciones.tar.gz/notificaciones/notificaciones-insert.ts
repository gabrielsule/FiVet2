import { Component } from '@angular/core';
import { NavController, NavParams, ToastController } from 'ionic-angular';
import { CommonService } from '../../services/common.service';
import { NotificacionesService } from '../../services/notificaciones.service';
import { CaballosService } from '../../services/caballos.service';
import { Alerta } from '../../model/alerta';
import { FormBuilder, Validators } from '@angular/forms';
import { NotificacionesPage } from './notificaciones';
import { Utils, Enum } from '../../app/utils';

@Component({
    templateUrl: 'notificaciones-insert.html',
    providers: [CommonService, NotificacionesService, CaballosService]
})

export class NotificacionesInsertPage {
    alertaEntity: Alerta;
    caballosList = [];
    formNotificaciones: any;

    constructor(public navCtrl: NavController,
        public navParams: NavParams,
        private _commonService: CommonService,
        private _notificacionesService: NotificacionesService,
        private _caballosService: CaballosService,
        private formBuilder: FormBuilder,
        public toastCtrl: ToastController) {
    }

    ngOnInit() {
        this.alertaEntity = new Alerta();
        this.getAllCaballos();
        this.initForm();
    }

    initForm() {
        this.formNotificaciones = this.formBuilder.group({
            Titulo: [this.alertaEntity.Titulo, Validators.required],
            FechaNotificacion: [this.alertaEntity.FechaNotificacion, Validators.required],
            HoraNotificacion: [this.alertaEntity.HoraNotificacion, Validators.required],
            Activa: [this.alertaEntity.Activa],
            Descripcion: [this.alertaEntity.Descripcion, Validators.required],
            CaballoId: [this.alertaEntity.CaballoId, Validators.required]
        });
    }

    getAllCaballos() {
        this._caballosService.getAll()
            .subscribe(res => {
                console.log(res);
                this.caballosList = res;
            });
    }

    saveNotificacion() {
        this._commonService.showLoading("Guardando..");
        this._notificacionesService.postNotificacion(this.formNotificaciones.value)
            .subscribe(res => {
                console.log(res);
                this._commonService.hideLoading();
                Utils.ShowToast(this.toastCtrl, Enum.TOAST_POSITION.bottom, "El registro se guardo exitosamente", 2000);
                //this.navCtrl.push(NotificacionesPage);
            }, error => {
                console.log(error);
                this._commonService.hideLoading();
                Utils.ShowToast(this.toastCtrl, Enum.TOAST_POSITION.bottom, "Error al guardar el registro", 2000);
            });
    }
}

